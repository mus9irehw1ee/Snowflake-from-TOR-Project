$(document).ready(function() {

  $('.bannerBtn').on('click', function() {
    $('.banner').toggleClass('hidden');
  });

});
